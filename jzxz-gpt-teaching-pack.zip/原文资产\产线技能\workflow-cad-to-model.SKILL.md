---
name: workflow-cad-to-model
description: 从图纸建立三维模型的跨软件产线——把底图/CAD/图片依次转成二维工程图（AutoCAD）、校验过的几何真源、三维模型（SketchUp/Rhino/Revit），并在每个接缝处做闸门检查。当用户要求"照着这个平面建模""把 CAD 转成 SU""按图纸精确建模""复刻这个户型"等需要从二维资料得到三维成果的任务时使用。不适用于纯自由创意建模（没有源资料）、只给既有模型补细节，或只要画二维图纸不出三维的情况——那些直接调对应软件技能。
metadata:
  origin: ai-generated
  version: "1.0.1"
---

# 图纸 → 模型 产线

## 三条硬约束（冲突时按序裁决）

1. **来源保真 > 一切。** 图上给定的数量、位置、footprint、朝向、贴墙关系不可改。视觉丰富度、材质数量、"保存成功"都不能抵消保真错误。
2. **空间逻辑 > 细节丰富。** 门扇撞椅、洁具超尺、楼板不交圈，先修这些，再谈加细节。
3. **一个任务只认一个几何真源。** 真源必须是磁盘上的文件，不能是对话里的坐标。

## 真源链

```
源资料（底图/CAD/尺寸表）
   ↓ 读图，记 assumptions
plan.json           ← AutoCADMCP 的几何真源（毫米、正 Y 向上、每个对象带 source 标记）
   ↓ validate_plan.py + 渲染预览图
二维工程图 .dwg
   ↓ 从同一份 plan.json 派生，不要另起一份
trace_manifest.json ← SketchUpMCP 的映射清单（图层→构件、公差、排除项）
   ↓ validate_trace.py 退出码 0
build_model.py      ← 建模脚本载体，参数集中在顶部 PARAMS
   ↓ py_compile 通过 → 私有 python 执行
.skp + 预览图 + model_state.json
```

**接缝原则：下游永远从上游文件派生，不要凭记忆重建。** 上一环节的 `assumptions` 与 `unresolved` 必须原样带到下一环节，不许在中途悄悄"补全"。

## 步骤

### 1. 认源（先分类，再动手）

| 输入 | 模式 | 该做的事 |
|---|---|---|
| 只有功能与尺寸 | 自主设计 | 先把假设写明，再出方案 |
| 图片 / 照片 / 扫描件 / 截图 | 有源重建 | 原图定几何，标注定语义，推断必须记账 |
| 已有 DWG/DXF | 增量绘制 | 不覆盖既有内容，只用本任务新图层 |
| 已有 .skp | 就地补丁 | 只删/隐藏出问题的命名组，不整模重建 |

判断不了就先问一句，不要一边假设一边当实测。

### 2. 建二维真源

按 `AutoCADMCP` 的 `plan.json` 规范写，关键字段：
- 单位毫米、笛卡尔坐标、正 Y 向上（`meta.orientation` 另写除外）
- 每个对象有稳定唯一 `id`、图层、来源：`explicit` 资料直给 / `inferred` 推导 / `unresolved` 只留中性线
- `meta.assumptions` 写单位、比例基准、方向、默认墙厚

**校验前置（第一笔图元之前）**：
```bat
"<私有python.exe>" "<AutoCADMCP技能目录>\scripts\validate_plan.py" plan.json --output plan_validation.json
"<私有python.exe>" "<AutoCADMCP技能目录>\scripts\render_interior_plan_preview.py" plan.json --output plan_preview.png
```
渲染完**必须用 `ViewImages` 真看过**再落图；有原图时做并排对照。

### 3. 落图

`plan_to_shorthand.py` 展开后一次交给 `draw_entities`；或按图层分批。核对 `created == total`，再 `export_data` 比对图层数与文字样式。保存到绝对 `.dwg` 路径。

### 4. 转三维

有源任务**必须走校验前置**，不许跳过直接建模：

```bat
"<私有python.exe>" "<SketchUpMCP技能目录>\scripts\validate_trace.py" "trace_manifest.json绝对路径"
```
退出码 `0` = 通过，`1` = 有 ERROR。**ERROR 全修完再建模**，WARN 在报告里写接受原因。写清单前先读 `references/trace-manifest-schema.md` + 校验器源码（校验器才是实际判定标准）。

### 5. 建模（脚本载体）

三条硬判据全满足才算脚本载体：脚本自己执行建模、参数集中在顶部 `PARAMS`、脚本自己校验并落状态文件。
自检问法：**删掉所有 `execute_ruby`、只跑那个 `.py`，模型还建得出来吗？**

每批 = 一组同类构件（一圈墙、一层楼板、一套门窗），一批一个 `start_operation`/`commit_operation`，失败 `abort_operation`。每批提交后查实体数，不要只看没报错。

大脚本用 `FileIO_Write` 写头 + 第一批，再 `FileIO_Append` 按 4–8 KB 追加；每次追加后读文件尾确认。中断后从最后一块已确认的分块续写，不要重写整份。

### 6. 验收（眼睛，不是返回码）

- 保存 `.skp`（走 `execute_ruby`，返回 `saved => true`），路径在建模型前就定好
- `ViewImages` 看自己生成的预览图，与参考图逐项比对，偏差写进 `known_issues`
- 有语义要求（床头朝向、电视朝向、门开方向）时，用截图或几何查询验证，不能只凭旋转属性数值断言
- 落 `model_state.json`：脚本路径、PARAMS 快照、批次列表、质量、`how_to_modify`、`known_issues`

## 单位换算表（最容易出错的地方）

| 场景 | 规则 |
|---|---|
| AutoCAD `plan.json` | 毫米 |
| Revit 全部参数 | 毫米（内部英尺由工具换算） |
| SketchUp `create_geometry` 坐标 | **英寸裸数字**，毫米 ÷ 25.4 |
| SketchUp `create_geometry` 的 `box` | **向下挤出**，`origin` 是顶面；底面落 z=0 要传 `[x, y, height]` |
| SketchUp Ruby | 一律写 `.mm` 后缀 |
| Blender / 3ds Max / Rhino | 开工先声明用米还是毫米，全程统一 |

同一任务里出现两种单位习惯时，把换算写成脚本里的具名常量，不要散落魔法数字。

## 断链备用路径

| 断在哪 | 降级做法 |
|---|---|
| CAD 连不上 | 脱离 CAD 直接写 `.dxf` |
| SketchUp 连不上 | 脱离 SU 自行写出 `.glb` |
| Revit 连不上 | 宿主 Python 跑 `scripts/verify_runtime.py` 只做检查，把结论告诉用户，不要自己改配置 |

降级不算失败，但要**在报告里明确写"走的是备用路径"**，不要模糊成正常交付。

## 完成报告格式

```
【真源】plan.json=<路径>；trace_manifest=<路径>；脚本=<路径>
【校验】validate_plan 退出码=<0/1>；validate_trace 退出码=<0/1>
【产物】.dwg=<路径>；.skp=<路径>；预览图=<路径>
【看图】已查看 <预览图> 并与 <参考图> 比对，偏差：<逐条或"无">
【保真】图层映射 <n>/<n>；未映射项及原因：<…>
【已知偏差】<known_issues 或"无">
```

没有"看图"那一行的完成报告，一律视为未完成。
