---
name: skill-router
description: 设计任务的技能调度索引——把已安装的技能按建模、出图、汇报、文档、资源、元工具分成六组，给出"这类请求该调哪个技能、按什么顺序串、哪一步必须停"的决策表与五条产线配方。当一次设计请求涉及多个软件或多份交付物、不确定该用哪个 MCP 或技能、需要把平面图→三维模型→效果图→汇报串成整条链路，或要盘点"我到底有哪些能力"时使用；单纯操作某一个软件时直接调对应技能，不必经过本技能。
metadata:
  origin: ai-generated
  version: "1.0.0"
---

# 技能调度索引

本技能只回答一件事：**这个需求该交给谁**。具体怎么做，交给被选中的那个技能自己的 SKILL.md。

## 一、六组技能与选择原则

| 组 | 技能 | 什么情况下选它 |
|---|---|---|
| **A 桌面 CAD/BIM** | `AutoCADMCP` `RevitMCP` | 要"精确、可交付、带图层/参数"的工程图或模型 |
| **B 桌面三维** | `SketchUpMCP` `RhinoMCP` `GrasshopperMCP` `BlenderMCP` `3dsmaxMCP` | 要造型、要可视化、要参数化 |
| **C 平面与版式** | `PhotoshopMCP` `IllustratorMCP` `InDesignMCP` | 要出图后期、矢量图面、成册排版 |
| **D 网页生成器** | `interior-3d-web` `site-planning-3d-web` `design-presentation-web` | 用户从配置界面点了"生成"，带来一份 `*生成配置.json` |
| **E 文档与资源** | `docx` `xlsx` `pdf` `ppt-master` `remotion-video` `arch-image-downloader` | 交付物是 Word / Excel / PDF / PPTX / 视频 / 图片素材 |
| **F 元工具与兜底** | `WindowsMCP` `configure-mcp` `error-recovery` `create-skill` | 配置坏了、软件连不上、要建新技能、GUI 无 API 可用 |

四条选择原则，冲突时从上往下：

1. **有专用 MCP 就绝不用 `WindowsMCP` 点软件。** 桌面自动化只在前者确实不存在对应工具时用；也绝不用它点 SketchUp / Revit / PS 的模态框。
2. **D 组是"配置驱动"，不是"自由创作"。** 只要用户带来了 `室内三维生成配置.json` / `场地规划生成配置.json` / `作品汇报网页生成配置.json`，就必须走 D 组对应技能，不要自己手写 HTML 或另起编辑器。
3. **同一份产物只认一个真源。** 一份任务里图形真源只允许一个（`plan.json`、`建模脚本`、`场景JSON`、`场地工程.json`、配置 JSON 五选一），后续所有步骤都从它派生。
4. **交付物类型决定 E 组归属**：主产物是 Word→`docx`，Excel→`xlsx`，PDF→`pdf`，PPTX→`ppt-master`。主产物是网页时不要顺手生成一份 docx 充数。

## 二、任务 → 技能 决策表

| 用户说的话 | 走哪个技能 | 备注 |
|---|---|---|
| 画个户型图 / 平面图 / 立面图 / 剖面图 / 节点图 | `AutoCADMCP` | 开工即告知"不支持天正对象" |
| 把这些图做成 SU 模型 / 按这个平面建模 | `workflow-cad-to-model` → `SketchUpMCP` | 有源任务必须走校验前置 |
| 建个 BIM 模型 / 出 Revit 明细表 | `RevitMCP` | 单位一律毫米 |
| 做个曲面 / 参数化 / 异形 | `RhinoMCP`，需要逻辑图时加 `GrasshopperMCP` | 两者共用 Rhino 实例，串行 |
| 出效果图 / 渲染 / 场景动画 | `workflow-visualization-output` → `BlenderMCP` 或 `3dsmaxMCP` | 渲前先定视角与构图 |
| 修图 / 去背景 / 批量调色 | `PhotoshopMCP` | 红线：不覆盖源文件 |
| 画分析图 / 矢量图面 / 总图填色 | `IllustratorMCP` | 坐标系 Y 轴方向先确认 |
| 排成画册 / 展板 / 作品集内页 | `InDesignMCP` | 先确认页数与开本 |
| 做汇报网页 / PPT 式 HTML | `design-presentation-web` | 必须找到本轮配置 JSON |
| 做室内三维可切换风格的网页 | `interior-3d-web` | 必须复现 `sha256` 校验 |
| 做场地总平面三维网页 | `site-planning-3d-web` | `--check` 通过后才组装 |
| 做 PPT / 课件 / 给幻灯片配旁白 | `ppt-master` | 先跑 `attribution_guard.py` |
| 写报告 / 说明书 / 合同 | `docx` | |
| 做测算表 / 清单 / 造价表 | `xlsx` | 红线：公式不硬编码结果 |
| 合并 PDF / OCR / 填表单 / 提图 | `pdf` | |
| 存一批建筑案例图 | `arch-image-downloader` | 只支持 ArchDaily / 谷德 / 有方 |
| 做个动效视频 | `remotion-video` | 需要 Node，用私有运行时 |
| 软件连不上 / 报错 / 更新失败 | `error-recovery`，配置层面加 `configure-mcp` | 不要自己改配置文件试 |
| 想把这套流程变成技能 | `create-skill` | 产物务必落在 `_user/` |

## 三、五条产线配方

跨两个以上软件时按配方走，每一步的闸门不可跳过。详细步骤见对应的 `workflow-*` 技能。

| 配方 | 链路 | 技能 |
|---|---|---|
| **① 图纸→模型** | 底图/CAD → 二维图 → 三维模型 → 保存交付 | `workflow-cad-to-model` |
| **② 模型→效果图** | 模型 → 视角/构图 → 渲染 → 后期 → 出图 | `workflow-visualization-output` |
| **③ 方案→汇报** | 素材/截图 → 汇报网页 或 PPTX → 文本成册 | `workflow-project-delivery` |
| **④ 图纸→文档交付** | CAD 图 → PDF 合并/标注 → Word 说明 → Excel 清单 | `workflow-drawing-docs` |
| **⑤ 全流程** | ①→②→③ 串联 | 三个 `workflow-*` 依次介入 |

配方之外的单软件任务，直接进对应技能，不要套配方徒增步骤。

## 四、跨技能的三条铁律

这三条在任何技能里都成立，写在这里是为了避免"每个技能都以为别人会管"：

1. **开工先定真源与产物路径。** 未保存的模型（`m.path` 为空）、没落盘的脚本、只存在于对话里的坐标，都不算真源。路径要在动手前告知用户。
2. **"工具返回成功"不等于"结果正确"。** 涉及可见几何、版式、图表时，必须用 `ViewImages` 亲眼看过产物图再声称完成；看过图却只写"已完成"、不写已知偏差，等于未完成。
3. **模态框永远交给用户点。** 任何软件弹出保存确认、权限提示、扩展警告，停下并输出等待确认，不要用 `WindowsMCP` 代替点击。

## 五、这个索引怎么维护

技能清单会变。发现下列情况时用 `GetExtendedSkillList` 重新盘点并更新本文件（本技能是自建的，可用 `SkillAuthoring_Update` 改）：

- 装了新技能，或某个技能被卸载
- 某个技能的 `description` 变了（说明它的边界变了）
- 某条配方反复失败，说明技能间的衔接约束写错了

完整的 23 个技能逐条清单、各自的必备闸门与备用路径见 [reference.md](reference.md)。只有在需要"某个技能到底有没有备用方案 / 它的完成闸门是什么"时才读它。
