# B 章：工具与 MCP 体系（教材化）

> 读者：要学习 JZXZ 的另一个 AI（GPT）。本章只讲"工具面"，共 8 节，每节固定五段：一句话结论 → 必须记住的 N 条事实（带数字）→ 一个具体例子 → 常见误区 → 自测题 2 道（含答案）。
> 数据来源：7 个 .NET 8 程序集的元数据静态解析（47 个内置工具逐字段还原）+ 12 个 MCP 服务配置与源码 + 一份 10,691 行运行日志的交叉验证。所有数字与原始报告一致。

---

## B1 两套工具体系：内置 47 个 vs MCP 570 个

**一句话结论**：JZXZ 的工具面由两套互不重叠的体系组成——47 个编译进程序内部的内置工具，和 12 个 MCP 服务带来的约 570 个外部工具。

**必须记住的 5 条事实（带数字）**
1. **内置工具 47 个，100% 在 `Runtime.Core.dll` 一个文件里**（534,016 字节）；其余 6 个业务程序集（主壳 Desktop.Shell 1.17 MB、Runtime.Shared、Workspace.Canvas、Desktop.Toolkit、Drawing.Viewer、Geometry.Viewer）**工具数都是 0**。
2. 47 个分布在 **16 个插件类 / 16 个命名前缀**下；运行时名字由两段拼成，如 `FileIO` + `Read` = `FileIO_Read`。
3. **MCP 配置 12 条**（11 条启用 + 1 条禁用示例），工具数合计 **570**：3ds Max 151、Revit 138、Photoshop 80、Illustrator 66、Rhino 38、Blender 28、InDesign 27、Windows 20、SketchUp 8、AutoCAD 7、Grasshopper 7。
4. 两套体系的**执行位置完全不同**：内置是宿主进程内的 C# 代码（起进程就能用），MCP 是外部软件能力（必须在对应软件里开服务才连得上）。
5. 所以"模型能调用的工具总数"不是 47，而是 47 + 570 的量级；但 MCP 那部分**按需连接、没连就不可用**。

**一个具体例子**
- 要读一个本地文本文件 → `FileIO_Read`，内置工具，不依赖任何外部软件，直接可用。
- 要在 SketchUp 里建一个盒子 → 只能走 MCP 的 `create_geometry`，前提是 SketchUp 已启动、且 `su_mcp` 扩展里点了 Start Server（端口 9876）。

**常见误区**
- ❌ "工具都在 47 个内置里"——不是，570 个 MCP 工具是另外一整层。
- ❌ "内置工具很多"——只有 47 个且只在一个 DLL 里；UI 层（主壳 1.17 MB）一个工具都没有，工具层与界面层彻底分开。MCP 也不是起进程就能用——SketchUp/Rhino/Blender/Revit 还要求先装插件、开软件。

**自测题**
1. 问：JZXZ 的工具分几套？各多少？
   答：两套。内置 47 个（全在 Runtime.Core.dll）+ MCP 12 个服务约 570 个工具。
2. 问：为什么在 Desktop.Shell.dll 里找不到工具？
   答：因为它工具数为 0；整个 UI 层不向模型暴露工具，工具面全部集中在 Runtime.Core.dll。

---

## B2 日志 26 个工具名的三分账：16 + 4 + 6

**一句话结论**：日志里出现 26 个工具名 ≠ 26 个内置工具，它是"内置 16 + 框架 4 + MCP 6"的混合物，这是 GPT 最容易记错的地方。

**必须记住的 5 条事实（带数字）**
1. 一份 **10,691 行**运行日志里共出现 **26 个不同的工具名**。
2. 拆账：**内置 16 个 + 框架 4 个 + MCP 6 个**（16 + 4 + 6 = 26）。
3. **框架 4 个**是 `todos_add / todos_complete / todos_remove / todos_get_remaining`，来自第三方包 `Microsoft.Agents.AI.dll` 的 `TodoProvider`，**不是 JZXZ 自研插件**；该 Provider 实际提供 5 个（还有 `todos_get_all`，日志未调用）。
4. **MCP 6 个**是：`execute_ruby`、`get_model_info`、`get_entity_info`（SketchUpMCP）；`manage_files`、`manage_session`（AutoCADMCP）；`Snapshot`（WindowsMCP）。
5. 归属判据很简单：**内置名必带"前缀_"（如 `FileIO_Read`），而框架工具和 MCP 工具都是裸名**（`todos_add`、`manage_session`、`Snapshot`）。

**一个具体例子**
- `manage_session(operations=[{"action":"status"}])` 返回的是 MCP 风格的 `{"content":[{"type":"text","text":…}]}` 信封，而不是内置工具的普通字符串。
- `get_model_info()` 在日志里直接抛 `MCP server process exited unexpectedly`——一句话证明它走 MCP 子进程，不是内置方法。

**常见误区**
- ❌ "日志 26 个就是内置工具数"——错，内置只有 16 个被实证，另外 10 个不是内置。
- ❌ "todos_* 是 JZXZ 自研、execute_ruby 是内置"——都错：todos_* 来自微软 Agent 框架包，execute_ruby 是 SketchUpMCP 的桥接工具，真正实现在 SketchUp 侧 Ruby 扩展。

**自测题**
1. 问：26 个日志工具名的正确拆法是？
   答：16 内置 + 4 框架（todos_*）+ 6 MCP，共 26。
2. 问：怎么一眼判断一个工具是内置还是 MCP？
   答：看名字——带"前缀_"形态的是内置（FileIO_Read）；裸名的是框架或 MCP（todos_add、manage_session、Snapshot）。

---

## B3 47 个内置工具按 14 个能力域分组

**一句话结论**：47 个内置工具按 14 个能力域记忆最快，每域只要抓住"工具数 + 代表工具 + 什么时候用 + 一个坑"。

**必须记住的事实（14 个域，合计 47）**

| 能力域 | 工具数 | 代表工具（2–3 个） | 什么时候用 | 一个坑 |
|---|---|---|---|---|
| 文件 | 3 | `FileIO_Read`、`FileIO_Write`、`FileIO_Append` | 读写文本、把脚本落盘再执行 | 技能目录写不进去；大文件必须用 `offset`/`limit` 分页 |
| 系统命令 | 2 | `SystemCommand_execute_command`、`SystemCommand_execute_powershell` | 跑 CMD/PS、用私有 Python 执行脚本 | `timeoutSeconds` 默认只有 120 秒，长任务会被掐断 |
| Python 环境 | 2 | `PythonEnv_InstallPackages`、`PythonEnv_ListInstalledPackages` | 脚本报缺库前先装 | `packages` 是空格分隔字符串；自己 `pip install` 会损坏环境 |
| 技能知识 | 2 | `SkillKnowledge_GetSkillKnowledge`、`SkillKnowledge_GetExtendedSkillList` | 任务沾边某技能，先读正文再照做 | 只返回知识不执行技能 |
| 技能创作 | 4 | `SkillAuthoring_Create`、`SkillAuthoring_Update`、`SkillAuthoring_ListMine` | 把可复用的成功流程沉淀成技能 | 只能改"自己创建的"技能；创建须先经用户同意 |
| MCP 管理 | 7 | `McpManager_check_mcp_status`、`McpManager_connect_mcp_server`、`McpManager_read_mcp_resource` | 调任何 MCP 工具前先巡检/连接 | 状态"已连接"不代表进程活着（可能已经崩了） |
| 交互 | 2 | `UserInteraction_present_options`、`ReminderNotification_show_reminder_notification` | 让用户在互斥选项里点选、主动提醒 | 自动执行模式下必须提供 `recommendedOption` |
| 视觉 | 1 | `ImageViewer_ViewImages` | 需要亲眼看图、多图横向对比 | 对比图必须一次传齐、单次最多 6 张；禁止再写 cv2/PIL 读像素 |
| 宿主应用 | 11 | `AppLauncher_launch_app`、`Browser_open_url`、`Clipboard_get_clipboard` | 启应用、开网页、读写剪贴板 | `open_url` 有两个（Browser_ / WebSearch_），优先带 `title` 的 Browser_ |
| 记忆 | 6 | `Memory_remember`、`Memory_recall`、`Memory_update` | 跨会话记住用户偏好与项目事实 | 纠错用 `update`，不要删了重记（会丢 ID 和元数据） |
| 知识库 | 2 | `KnowledgeBase_search_knowledge_base`、`KnowledgeBase_list_knowledge_bases` | 问本地文档能回答的问题 | 本机 RAG 向量库 `ragstore.db` 缺失时用不了 |
| 检索 | 2 | `WebSearch_web_search`、`WebSearch_open_url` | 联网查资料 | 本机未配 Tavily Key，可能不可用 |
| 时间 | 3 | `Time_Now`、`Time_Today`、`Time_UtcNow` | 需要"现在/今天"这种绝对时间 | 模型通常能自己推断，用得少 |

**一个具体例子**（一次建模任务的典型工具链）
`FileIO_Write` 写建模脚本 → `SystemCommand_execute_command` 用私有 Python 执行 → `ImageViewer_ViewImages` 看图验收 → `SkillKnowledge_GetSkillKnowledge` 读产线技能 → `todos_add` 记清单 → `todos_complete` 逐步销账。整条链里没有任何"万能工具"，全是细粒度组合。

**常见误区**
- ❌ 以为文件域只有读和写——还有 `FileIO_Append`（专为大脚本分块写入设计）。
- ❌ 以为视觉工具能生成图——`ImageViewer_ViewImages` 只把磁盘图片读回来给模型看，不生成、不渲染。
- ❌ 以为"宿主应用 11 个"是 11 种软件——它们是启动器/浏览器/剪贴板三类操作的 11 个动作。

**自测题**
1. 问：14 个能力域里工具数最多的是哪个？几个？
   答：宿主应用，11 个（AppLauncher 5 + Browser 3 + Clipboard 3）。
2. 问：想把一段流程存成可复用技能，该调哪些工具？
   答：`SkillAuthoring_ListMine` 确认归属 → `SkillAuthoring_Create` 建新技能（或 `Update` 改自己建的），辅助文件用 `WriteAsset`；不能用 FileIO 写技能目录。

---

## B4 31 个从未被调用：能力齐全 ≠ 被使用

**一句话结论**：47 个内置工具里有 31 个在该日志中 0 次调用——工具做得最齐的家族，恰恰是最没人用的家族。

**必须记住的 4 条事实（带数字）**
1. **31 / 47 未实证（0 次调用），16 / 47 已实证**。
2. **整族被冷落**：`Memory_*` 6 个、`SkillAuthoring_*` 4 个、`Browser_*` 3 个、`Clipboard_*` 3 个、`Time_*` 3 个、`KnowledgeBase_*` 2 个、`WebSearch_*` 2 个，合计 23 个；另外 8 个零散未用（2 个 AppLauncher、4 个 McpManager、`SkillKnowledge_GetExtendedSkillList`、`ReminderNotification_show_reminder_notification`）。
3. **高频对照**：`FileIO_Read` 90 次、`SystemCommand_execute_command` 85 次、`FileIO_Write` 68 次——头部三件套占了绝大部分调用。
4. 连系统提示词反复点名的 `SkillAuthoring_*`（写技能的唯一入口）也是 0 次——**提示词写了 ≠ 实际会用**。

**一个具体例子**
日志里从未出现 `Memory_remember`：需要"记住"的场合，模型选择写文件或依赖会话记忆，而不是调长期记忆工具。同理，`Clipboard_*` 三个工具在整份日志里一次没被摸过——尽管它们是"把内容粘到别的软件"最直接的通道。

**常见误区**
- ❌ 把"未实证"当"不存在"——它们与已实证的 16 个是同一套 `[AgentTool]` 注册的，静态存在性 100% 确认，只是场景没触发。
- ❌ 用"47 个工具"评估实际能力——准确说法是"声明 47、实践 16"；未用也不等于坏，多是任务类型单一（纯建模会话不需要记忆/知识库/剪贴板）。

**自测题**
1. 问：47 个内置工具里有多少个在该日志里从未被调用？
   答：31 个（16 个已实证）。
2. 问：为什么"提示词里提到"不能当作"会被使用"的证据？
   答：SkillAuthoring_* 4 个工具在提示词里被明确要求使用，但日志里 0 次调用；使用与否取决于任务类型和模型决策。

---

## B5 命名规则与冲突：内置带前缀、MCP 裸名

**一句话结论**：内置工具全部是"前缀_短名"、MCP 工具全部是裸名，两套命名空间天然隔离；真正会撞名的只有 MCP 之间。

**必须记住的 6 条事实（带数字）**
1. 运行时名 = **插件 Name + "_" + 短名**，如 `FileIO` + `Read` = `FileIO_Read`。**前缀不等于类名**：类 `PythonEnvironmentPlugin` 的前缀是 `PythonEnv`，类 `McpManagementPlugin` 的前缀是 `McpManager`。
2. **共 16 个前缀**：FileIO、ImageViewer、Time、UserInteraction、AppLauncher、Browser、Clipboard、KnowledgeBase、McpManager、Memory、PythonEnv、ReminderNotification、SkillAuthoring、SkillKnowledge、SystemCommand、WebSearch。
3. 短名风格混用：**32 个 snake_case**（`open_url`、`list_mcp_resources`、`execute_command`）+ **15 个 PascalCase**（`Read`、`InstallPackages`、`GetSkillKnowledge`）。
4. **同短名不同前缀是合法的**：`open_url` 出现 2 次（`Browser_open_url`、`WebSearch_open_url`），`Update` 出现 2 次（`Memory_update`、`SkillAuthoring_Update`）。
5. MCP 工具名**原样透传、无前缀**：`execute_ruby`、`manage_session`、`Snapshot`、`gh_inspect`、`get_addon_status`。
6. 注册端**既不改名也不去重**：内置注册只做"批量加入 + 打日志"，MCP 注册只做"加锁 → 逐个加入 → 计数"。

**一个具体例子**
想让用户看到某个网址：优先 `Browser_open_url`（参数是 `url` + `title`，说明更详细）；`WebSearch_open_url` 只有 `url`。两者功能重叠但前缀不同，靠前缀区分归属——这就是"同短名不同前缀"设计的价值。

**常见误区**
- ❌ 以为 `open_url` 只有一个——有两个，且参数不同。
- ❌ 以为 MCP 工具会带服务器前缀（如 `sketchup_execute_ruby`）——不会，就是裸名，所以不同 MCP 服务之间可能撞名。
- ❌ 以为重名会报错——不会，注册端只做集合加入，没有去重；命名纪律要靠配置方自己守。

**自测题**
1. 问：`PythonEnv_InstallPackages` 的前缀是什么？为什么不是类名？
   答：前缀是 `PythonEnv`。前缀来自插件类里声明的 `Name` 属性值，不是类名（类名是 PythonEnvironmentPlugin）。
2. 问：内置和 MCP 工具会不会撞名？
   答：不会。内置都是"前缀_短名"带下划线形态，MCP 都是裸名，两套命名空间天然隔离；风险在 MCP 与 MCP 之间。

---

## B6 12 个 MCP 的启动方式与端口

**一句话结论**：12 条 MCP 配置 = 10 条 stdio（宿主起子进程）+ 2 条 SSE（宿主只做客户端），端口全部是 127.0.0.1 本地回环。

**必须记住的 7 条事实（带数字）**
1. 配置 **12 条**：11 条启用 + 1 条禁用示例（`example-mcp-server`，`http://localhost:3001/sse`，仅作格式参考）。
2. 传输方式只有两种：**stdio 10 条、SSE 2 条**（GrasshopperMCP 与禁用模板）。
3. **端口清单**（全部 loopback）：SketchUp **9876**、Rhino **1999**、Blender **9877**、Grasshopper **26929**（`/mcp`）、3ds Max **8765**（TCP 兜底，首选命名管道）、Revit **27183–27192**；AutoCAD 另有可选的 Web 控制台 **8888**（非必需）。
4. **不用端口的 5 条**：Windows（进程内 UI Automation/截图）、AutoCAD（COM）、Photoshop、Illustrator、InDesign（COM/ExtendScript）——这 5 条靠 COM 或进程内调用，不开端口。
5. 启动器构成：11 条启用服务里 **7 个 Python**（共用同一套私有 Python 3.11.8 + fastmcp）、**3 个 Node**（Photoshop / Illustrator / Revit）、**1 个外部 SSE**（Grasshopper，由 Rhino 8 侧提供端点，应用只连不发）。
6. 工具数合计 **570**；日志实测连上过 SketchUp **8**、AutoCAD **7**、Windows **20**，与静态统计一致。
7. **前置条件是"打开软件 + 装插件"**：SketchUp/Rhino/Blender/Grasshopper/3ds Max/Revit 需要各自插件；AutoCAD 与 Adobe 系不需要插件，但要软件能启动。

**一个具体例子**（SketchUp 完整链路）
`{PythonExe}` 启动 `Settings\Skills\SketchUpMCP\stdio_bridge.py` → 桥接脚本做 stdin/stdout JSON-RPC 与 TCP 的透传 → 连 `127.0.0.1:9876` → SketchUp 内的 Ruby 扩展 `su_mcp` 执行；**工具定义不在 Python 侧，而在 SketchUp 侧 8 个 `.rb` 文件里**，所以恰好 8 个工具。桥接层还带闸门：`execute_ruby` 里想新建几何但工作区没有近期 `.py` 脚本时，直接拒绝。

**常见误区**
- ❌ 以为 Grasshopper 的 SSE 是应用起的——不是，必须 Rhino 8 里放好 GrasshopperMCP 组件。
- ❌ 以为所有 MCP 都一个端口——每个软件各自不同；Blender 特意用 9877，就是为了避开 SketchUp 的 9876。
- ❌ 以为 Adobe 系要装插件、要端口——它们走 COM，不需要插件也不需要端口。

**自测题**
1. 问：12 条 MCP 里 stdio 和 SSE 各几条？
   答：stdio 10 条、SSE 2 条（其中 1 条是禁用模板）。
2. 问：Revit 和 3ds Max 各走什么通道、什么端口？
   答：Revit 走 TCP，端口范围 27183–27192（由 Add-In 写出，非法则回退 27183）；3ds Max 优先命名管道 `\\.\pipe\3dsmax-mcp`，TCP 兜底 8765。

---

## B7 插件机制：C# 编译型工具，丢 DLL 后重启

**一句话结论**：插件是"用 `[AgentTool]` 标注的 C# 方法编译成 DLL、放进 `Settings\Plugins\`、重启后变成工具"，和技能（Markdown）、MCP（外部服务）是三件不同的事。

**必须记住的 6 条事实（带数字）**
1. 插件目录 `Settings\Plugins\` 当前 **0 个 DLL**（只有一份 README.txt）→ 所以那 47 个就是当前全部内置工具面。
2. 开关在配置里：`"Plugins": { "EnableDynamicLoading": true }`。
3. 官方 README 给的 **5 步**：建 .NET 8 类库 → 引用 `Runtime.Core`（提供 `[AgentTool]`）与 `Microsoft.Extensions.AI.Abstractions` → 写带 `[AgentTool]` 的方法 → 编译成 DLL 放进目录 → **重启应用**自动加载。
4. 加载时机在启动序列的 "Services initialized" 阶段 → **改 DLL 不会热生效，必须重启**。
5. 是否加载成功看日志：会打一行 `已注册插件: {插件Name} ({插件Description})`。
6. 插件的工具名规则与内置一致：**前缀 + 短名**；前缀来自插件类的 `Name` 属性（若继承 `PluginBase`）。

**一个具体例子**（README 原文骨架）
```csharp
using System.ComponentModel;
using Runtime.Core.Domain.Plugins;

internal class MyCustomPlugin
{
    [AgentTool("my_function")]
    [Description("A custom function")]
    public string MyFunction([Description("Input parameter")] string input)
        => "Result: " + input;
}
```
编译成 DLL 丢进 `Settings\Plugins\` → 重启 → 模型工具表里就多一个 `my_function` 形态的工具（前缀由插件类名/属性决定）。

**常见误区**
- ❌ 以为改了 DLL 立刻生效——必须重启，因为插件在启动装配阶段加载。
- ❌ 把插件当技能——技能是 Markdown 提示词（教模型怎么做），插件是可执行 C# 代码（给模型新动作）。
- ❌ 把依赖 DLL 一起塞进插件目录——会和宿主自带版本冲突，正确做法是引用宿主目录里已有的 DLL。

**自测题**
1. 问：想让 JZXZ 多一个"算面积"的工具，最小改动是什么？
   答：写一个 .NET 8 类库，用 `[AgentTool]` + `[Description]` 标注方法，编译成 DLL 放进 `Settings\Plugins\`，重启应用。
2. 问：怎么确认插件已经被加载？
   答：在日志里搜 `已注册插件:`，后面会带插件的 Name 与 Description。

---

## B8 三条最重要的工具设计范式

**一句话结论**：JZXZ 的工具不是"函数堆"，而是用工具名、描述和权限在替模型写行为规范——这三条范式最值得学。

**必须记住的 3 条范式（带数字/原文证据）**
1. **工具描述即提示词**：`[Description]` 里写的不只是功能，还有行为纪律。例：系统命令工具的描述直接写 "Never 'pip install' here — use PythonEnv_InstallPackages instead"；看图工具写"看就行了——不要再写 cv2/PIL 去读取或分析像素"。实测 47 条描述里 **27 条中文、20 条英文**，**63 个参数里 59 个带参数级描述**——描述是模型判断"这个参数填什么"的唯一线索。
2. **目录级权限硬约束**：关键权限写死在执行层，不靠模型自觉。例：`FileIO_Write` 写明技能目录写不进去，改技能必须走 `SkillAuthoring_*`；`SkillAuthoring_Update` 只允许改带"你创建"来源标记的用户技能；SketchUp 桥接层甚至拦截 `execute_ruby`，要求先落盘 `.py` 脚本才允许建几何。
3. **状态机式工具**：用工具顺序把流程固定下来。例：MCP 三件套 `check_mcp_status` → `connect_mcp_server` → 调具体工具 → `disconnect_mcp_server`；Todo 生命周期 `todos_add` → `todos_complete` / `todos_remove` → `todos_get_remaining`；`present_options` 把"用户点击"变成工具返回值，让模型中途拿到决策再继续。

**一个具体例子**
一次建模任务的范式组合：`FileIO_Write` 落脚本（范式 1 的产物纪律：大代码不要塞命令行）→ `execute_command` 跑（范式 2：禁止在这里装包）→ `ViewImages` 验收（范式 1：不许写代码读像素）→ `todos_complete` 记账（范式 3：每完成一步必销账）。

**常见误区**
- ❌ 以为工具描述越短越好——对这个体系而言描述就是"使用说明书 + 纪律条款"，省不得。
- ❌ 以为权限靠提示词就够、工具越"万能"越好——真正的硬约束在执行层（目录保护/来源标记/闸门）；JZXZ 宁可 47 个细粒度工具，也不要一个万能入口，因为细粒度才可审计、可限权、可组合。

**自测题**
1. 问：为什么 `pip install` 被专门做成独立工具 `PythonEnv_InstallPackages`？
   答：因为它需要串行化并发安装并做镜像回退，绕过它会损坏环境；工具描述里明确禁止在系统命令里直接 pip——这就是"工具描述即提示词"的典型。
2. 问：`todos_*` 体现了哪种设计范式？
   答：状态机式工具——add 建清单、complete/remove 推进状态、get_remaining 查询剩余，把多步骤任务的流程固定成可审计的状态迁移。

---

## 本章速记卡（10 个数字）

| 数字 | 含义 |
|---|---|
| 47 | 内置工具总数（全在 Runtime.Core.dll，16 个插件类） |
| 16 | 日志实证的内置工具数 |
| 31 | 日志里 0 次调用的内置工具数 |
| 4 | 框架工具 todos_*（Microsoft.Agents.AI.TodoProvider，另有第 5 个 todos_get_all 未用） |
| 6 | 日志里实证的 MCP 工具数 |
| 26 | 日志出现的工具名总数 = 16 + 4 + 6 |
| 12 / 570 | MCP 服务条数（11 启用 + 1 禁用模板）/ 其工具总数 |
| 10 / 2 | MCP 传输：stdio 10 条 / SSE 2 条 |
| 9876 / 1999 / 9877 / 26929 / 8765 / 27183–27192 | 各 MCP 端口（SU / Rhino / Blender / GH / 3dsMax / Revit） |
| 0 | Settings\Plugins\ 里的第三方 DLL 数（插件机制空载） |
