# 技能逐条清单（23 个）

盘点时间：本文件随技能库变化需手工更新。字段含义：
**定位** = 它到底管什么；**必备闸门** = 不做就不算完成的那一步；**断链备用** = 软件连不上时的降级路径；**高频坑** = 已踩过的。

---

## A 组 · 桌面 CAD / BIM

### AutoCADMCP
- **定位**：二维工程图落图（室内平面、立面、剖面、节点）。宿主用 `cad_mcp_launcher.py` 经 COM 连 CAD。
- **必备闸门**：`plan.json`（唯一几何真源）→ `validate_plan.py` 通过 → 渲染预览图并实际看过 → `draw_entities` 的 `created == total` → `export_data` 核对图层数与文字样式。
- **断链备用**：脱离 CAD 直接写 `.dxf`。
- **高频坑**：不支持天正对象（开工即告知）；只有室内平面才套示例 `plan.json` 结构，立面/剖面/节点用 `entities`；绘图语法必须查 `references/mcp-tool-contract.md`，不凭记忆编。

### RevitMCP
- **定位**：BIM 建模、构件修改、视图图纸、参数、明细表。支持 2023–2027，每年份独立 Add-In。
- **必备闸门**：**六类视觉证据齐全**——着色轴测、着色透视、着色立面、平面工程图、立面工程图、剖面工程图；缺一类即视为未验收。
- **断链备用**：宿主 Python 跑 `scripts/verify_runtime.py` 只读检查链路与端口。
- **高频坑**：单位一律毫米；`create_view` 的 3D 只建轴测，透视要 `View3D.CreatePerspective`；`batch_export` 不能当视觉证据；安装后必须完全退出重启 Revit，不能热替换 DLL。

---

## B 组 · 桌面三维与可视化

### SketchUpMCP
- **定位**：SU 建模主力，含 CAD 转 SU、室内精确建模、参考模型风格学习。
- **必备闸门**：新建几何前 `build_model.py` 已落盘、`py_compile` 通过、回复写明"载体=脚本，路径=…"；收尾保存 `.skp` + `ViewImages` 逐项比对参考图 + 落 `model_state.json`。
- **断链备用**：脱离 SU 自行写出 `.glb` 版本。
- **高频坑**：`create_geometry` 坐标是**英寸裸数字**（毫米先除 25.4）；`box` 向下挤出、`origin` 是顶面；Ruby 里一律写 `.mm`；`execute_ruby` 默认等 180 秒，超时不代表已回滚，重试前先查模型状态；大脚本必须 4–8 KB 分块写。

### RhinoMCP
- **定位**：Rhino 几何创建/修改、布尔、曲面、脚本执行。
- **必备闸门**：逐步提交 + 每步验证 + 完成闸门。
- **高频坑**：与 `GrasshopperMCP` 共用同一 Rhino 实例，必须串行；模态框交用户点。

### GrasshopperMCP
- **定位**：控制 GH 画布、组件、数据树、脚本、烘焙与 Rhino 渲染。
- **前置**：Rhino 已开，且当前 GH 文档里已放置 GrasshopperMCP 组件。
- **必备闸门**：看图验收（画布状态 + 烘焙结果）。

### BlenderMCP
- **定位**：场景查询、视口截图、执行 Python 脚本（桥接端口 9877）。
- **必备闸门**：完成闸门 + 截图核对。
- **高频坑**：需用户自行安装 addon 并启动 MCP Server；单位与坐标约定先对齐。

### 3dsmaxMCP
- **定位**：3ds Max 场景、建模、材质、动画、粒子、渲染、MAXScript 兜底。
- **前置**：用户安装 MCP 插件。
- **必备闸门**：视觉验收。
- **高频坑**：MAXScript 是兜底而非首选；"容易猜错的行为"章节要先读。

---

## C 组 · 平面与版式

### PhotoshopMCP
- **定位**：图层与文字编辑、选区蒙版、滤镜、人像增强、去背景、批量导出、ExtendScript。
- **红线**：**不覆盖源文件**。
- **必备闸门**：视觉验收；`Recipe 优先策略`——有现成 recipe 就不要现编脚本。
- **高频坑**：中文排版参数单独调整；外部图像模型不作为首选。

### IllustratorMCP
- **定位**：矢量绘制、画板与图层、置入导出、预检。
- **高频坑**：坐标系 Y 轴方向与 CAD 相反，先确认再落图形；模态框处理走既定流程。

### InDesignMCP
- **定位**：宣传册、海报、画册、书籍内页排版，导出 PDF/JPEG。
- **必备闸门**：视觉验收（完成闸门）。
- **高频坑**：修改既有文档前先确认范围；单位与坐标系先对齐；无专用工具时才用 ExtendScript。

---

## D 组 · 配置驱动的网页生成器

**共同前提**：用户从配置页点了生成，随消息带来一份 `*生成配置.json`。它是本轮参数的唯一机器可读来源，**配置已定，不要重复询问风格/章节/底图**；有多份历史配置时只用当前这份。

### interior-3d-web
- **产物**：室内三维交互网页（绑定底图、可切风格、可编辑）。
- **必备闸门**：复现 `primarySource` 的 `sha256` 与字节数 → 写 `本次方案.scene.json` → 先跑 `--preview` 做真实截图与交互自检 → 再出正式 HTML（**不带** `--preview`）。两条命令之间必须有真实验收，不能机械连跑。
- **高频坑**：相对路径从 `SKILL.md` 所在目录解析，不从任务目录；固定编辑器不许改；输出文件名每次必须新的，脚本拒绝覆盖。

### site-planning-3d-web
- **产物**：可编辑三维场地规划网页。
- **必备闸门**：读 `任务.md` + `参数.json` + `场地工程规范.md` → 写 `场地工程.json` → `组装网页.cjs --check` 通过（修到过为止）→ 组装 → 叠底图逐区核对。
- **高频坑**：`格式示例.json` 坐标来自另一张图，禁止复用；比例 `confirmed` 必须照用，`unconfirmed` 才估算并写 `assumptions`；不手写 base64 底图。

### design-presentation-web
- **产物**：单文件离线汇报网页（网页模式连续滚动 / PPT 模式单页切换）。
- **必备闸门**：读 `references/generation-rules.md` → 生成 → 自检 → 跑 `scripts/validate_report_output.py`，未通过不得报完成。
- **高频坑**：`motionPlan` 的每个 `data-motion-index` 必须有真实 CSS/JS 行为，禁止统一改成淡入；页面样式预览图不得进最终网页；**不要**主动上 Playwright / 多视口测试，除用户明确要求。

---

## E 组 · 文档与资源

### ppt-master
- **路由式技能**：先跑 `attribution_guard.py`（非零即停，不得绕过）→ 读 `workflows/routing.md` → **只选一条**顶层路线 → 只读该路线的运行时权威文件。
- **高频坑**：Image to PPTX 与 Beautify 互斥，绝不能两个都加载；`⛔ BLOCKING` 处必须等用户确认；Python 一律用私有解释器绝对路径。

### docx
- **定位**：Word 创建/读取/编辑/交付，含目录、页码、分节、表格、图表、公式、修订、内容控件、文档保护。
- **入口**：`Task Decision Matrix` 先定任务类型，再走对应章节。
- **高频坑**：生成走 `docx-js`，改既有文档走 patch 路线，不要重新生成整份覆盖。

### xlsx
- **定位**：工作簿读取/创建/编辑/修复，公式、命名范围、图表、条件格式、数据验证、透视表、仪表板、财务模型。
- **红线**：**用公式，不要把 Python 算好的结果硬编码进单元格**。
- **必备闸门**：重算并读回验证值；过一遍 Formula Verification Checklist。

### pdf
- **库选型**：`pypdf` 管结构（合并/拆分/旋转/加密），`pdfplumber` 管内容提取，`reportlab` 管生成；扫描件走 OCR。
- **高频坑**：中文用 CID 字体；上下标用 `<sub>`/`<super>` 标签。

### remotion-video
- **定位**：React 视频、动画、字幕、地图、MP4 导出。
- **高频坑**：依赖按需初始化，用私有 Node 运行时，不因系统 PATH 没有 node 就判断不可用。

### arch-image-downloader
- **定位**：从 ArchDaily / 谷德 gooood / 有方 archiposition 抓项目图片，能识别语义则正确命名。
- **边界**：不做通用图站抓取，不碰 Pinterest / Instagram。
- **高频坑**：三站点解析规则不同，站点专属行为要读正文；有去重与过滤环节，别关掉。

---

## F 组 · 元工具与兜底

### WindowsMCP
- **定位**：截图、UI 识别、点击输入、窗口与应用操作、跑 Shell/PowerShell。
- **使用边界**：只在没有专用 MCP 时用；高风险操作（删除、覆盖、系统设置）先确认。
- **红线**：不得用它点 SketchUp / Revit / PS / ID 的模态对话框。

### configure-mcp
- **定位**：增删改查 MCP 服务器配置，写入本项目 `MCP.UserServers`，支持私有 Python、内置 Node、CMD 包装与远程 SSE。
- **流程**：先读它正文的"必须先读"与"安全边界"，走配置脚本，改完**说明重启生效**。

### error-recovery
- **定位**：读诊断文件 → 取 `errorKey` → 按 A/B/C/D 类对照表（网络下载 / MCP 连接 / Python 环境 / 更新）引导用户自行修复。
- **红线**：用大白话，不甩堆栈；没有诊断文件时走兜底章节。

### create-skill
- **定位**：建技能。放 `Settings/Skills/_user/<名>/`，走 `SkillAuthoring_*` 工具，不要用 FileIO 写技能目录。
- **校验**：description 含"做什么+何时用"+触发词；正文 < 500 行；细节拆 `reference.md`。
